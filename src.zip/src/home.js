import React from 'react';
//import axios from 'react';
import { Link } from 'react-router-dom';
//import PhotoDetail from './photoDetail.js'; 
class Home extends React.Component{
	constructor(){
		super();
		this.state = {
			photos:[]
		}
	}
	componentDidMount(){
   fetch('https://jsonplaceholder.typicode.com/photos')
  .then(response => response.json())
  .then(json => this.setState({
	  photos:json.splice(0, 9)
	  
  }))
	}
render(){
	return(
	<div className="container">
	<hr/>
	<div className="row">
	{this.state.photos.map((photo, id) =>{
	return(<div key={photo.id} className="col-md-4">
		<div className="card">
		  <img src={photo.thumbnailUrl} alt='abc' style={{width:'100%'}}/>
		  <div className="card-body" style={{height:'150px'}}>
			<h5 className="card-title">{photo.title}</h5>
			<p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
			<Link to={"/${photo.id}"} className="btn btn-primary">Go View</Link>
		  </div>
		  </div>
		  </div>);
		  
	})}
	</div>
	</div>
	)
}

}

export default Home; 