import React from 'react';
import './App.css';
import Home from './home';
import About from './about';
import Contact from './contact';
import {BrowserRouter, Route, Switch, NavLink} from 'react-router-dom';
import PhotoDetail from './photoDetail.js'; 
//import {withRouter} from 'react-router-dom';

class App extends React.Component{
    render(){
      return (
        <BrowserRouter>
        <div className="App">
        <nav className="navbar navbar-default">
        <div className="container-fluid">
            <div className="navbar-header">
                <NavLink className="navbar-brand" to="#">WebSiteName</NavLink>
            </div> 
            <ul className="nav navbar-nav">
                <li className="active"><NavLink exact to="/">Home</NavLink></li>
                <li className="active"><NavLink to="about">About Us</NavLink></li>
                <li className="active"><NavLink to="contact">Contact Us</NavLink></li>
            </ul>
        </div>
          <Switch>
          <Route exact path="/" component= {Home} />
          <Route path="/about" component= {About} />
          <Route path="/contact" component= {Contact} />
		      <Route path="/:photo_id" component ={PhotoDetail} />
          </Switch>
          </nav>
        </div>
        </BrowserRouter>
      );
  }
}

export default App;
