import React from 'react';
//import App from './App.css';

class Contact extends React.Component{
	constructor(){
		super();
		this.state={
			tasks:[
				{name:'kamal', completed:false},
				{name:'kishor', completed:false},
				{name:'Sunder', completed:false},
				{name:'Siddharth', completed:false}
				], currentText:''
			}
	}
changeStatus = (index)=> {
	let tasks = this.state.tasks;
	let task = tasks[index];
	//console.log(this.state.tasks[index])
	task.completed = !task.completed;
	this.setState({
		tasks:tasks
	})
}
deleteItem = (index) =>{
	//console.log(index);
	let tasks = this.state.tasks;
	tasks.splice(index, 1);
	this.setState({
		tasks:tasks
	})
}
newText = (newValue)=>{
	this.setState({
		currentText:newValue.target.value
	})
}
addText = (evt) =>{
	evt.preventDefault();
	let tasks = this.state.tasks;
	let currentText = this.trim(this.state.currentText);
	if(!currentText){
		return true
	}
	console.log(currentText);
	tasks.push({
		name:currentText,
		completed:false
	})
	this.setState({
		tasks:tasks,
		currentText:''
	})
	
}
trim(currentText){
	return currentText.replace(/^\s+|\s+$/gm,'');
}

editText = (index, newValue) =>{
 	let tasks = this.state.tasks;
	let task = tasks[index];
	task['name']=newValue
	this.setState({
		tasks:tasks
	})
}
	render(){
		return(
			<section className="container">
			<InsertData 
				currentText = {this.state.currentText}
				newText = {this.newText}
				addText = {this.addText}
				/>
				
<hr/>
			<ul style={{paddingLeft:'0px'}}>
			{this.state.tasks.map((task, index)=>{
				return <TodoList 
						key={index} 
						index={index}
						detail={task}
						clickHendler = {this.changeStatus}
						deleteItem = {this.deleteItem}
						editText = {this.editText}
						/>
			})}
			</ul>
			</section>
		)
	}
}
class TodoList extends React.Component{
	constructor(){
		super();
		this.state={
			isEditing:false
		}
	}
ToggleTask = () =>{
	let isEditing = this.state.isEditing;
	this.setState({
		isEditing : !isEditing
	})
}
updateItem = (evt) =>{
	evt.preventDefault();
	console.log(this.input.value);
	this.props.editText(this.props.index, this.input.value);
	this.ToggleTask();
}
RenderForm = () =>{
	return(
			<form onSubmit={this.updateItem}>
				<input type="text" ref={(value)=>{
					this.input=value
				}} defaultValue={this.props.detail.name}/>
				<button>Update Task</button>
			</form>
	)
}
RenderList = () =>{
return(
		<li onClick={()=>{
				this.props.clickHendler(this.props.index)
			}} className={this.props.detail.completed ? 'completed' : ''}>
			{this.props.detail.name}
			<button onClick={(evt)=>{
				evt.stopPropagation();
				this.props.deleteItem(this.props.index)
			}}>Delete</button>&nbsp;
			<button onClick={(evt)=>{
				evt.stopPropagation();
				this.ToggleTask();
			}}>Edit Item</button>
			</li>
)
}
	render(){
		const isEditing = this.state.isEditing; 
		return(
			<section>
			{isEditing ?  this.RenderForm() : this.RenderList()}
			
			
			
			
			</section>
		)
	}
}
class InsertData extends React.Component{
	render(){
		return(
			<section className="container">
			<h1>To Do Form</h1>
			<form onSubmit={this.props.addText}>
				<input type="text" 
				value={this.props.currentText} 
				onChange={this.props.newText}
				/>
				<button type="submit">Submit</button>
			</form>
			</section>
		)
	}
}

export default Contact;