import React from 'react';

class About extends React.Component{
	constructor(){
		super();
		this.state = {
			tasks:[
					{name:'kamal kishor', completed:false},
					{name:'Gudiya Lavaniya', completed:false},
					{name:'sudeer Singh', completed:false},
					{name:'krishna Mithas', completed:false}
					],
					currentText:''
		}
	}
clickHendler = (index) =>{
	let tasks = this.state.tasks;
	let task = tasks[index];
	console.log(index);
	task.completed = !task.completed
	this.setState({
		tasks:tasks
	})
}
deleteItem = (index)=>{
	let tasks = this.state.tasks;
	tasks.splice(index, 1);
	this.setState({
		tasks:tasks
	})
}
newText = (newValue) =>{
	this.setState({
		currentText : newValue.target.value
	})
}
addText = (evt) =>{
	evt.preventDefault();
	let tasks = this.state.tasks;
	let currentText = this.trim(this.state.currentText);
	if(!currentText){
		return true
	}
	tasks.push({
		name:currentText,
		completed:false
	})
	this.setState({
		tasks:tasks,
		currentText:''
	})
	console.log(tasks);
}
trim(currentText){
	return currentText.replace();
}

editTasks = (index, newValue) =>{
	console.log(index, newValue);
	let tasks = this.state.tasks;
	let task = tasks[index]
	task['name']=newValue;
	this.setState({
		tasks:tasks
	})
	
}
    render(){
    return(
        <div className="container">
            <h1>Welcome To About Us Page</h1>
			<TodoForm 
				currentText = {this.state.currentText}
				newText = {this.newText}
				addText = {this.addText}
				/>
				<hr/>
			<ul>
			{
			this.state.tasks.map((task, index)=>{
				return <TodoList 
						key={index} 
						detail={task} 
						index = {index}
						clickHendler = {this.clickHendler}
						deleteItem = {this.deleteItem}
						editTasks = {this.editTasks}
						/>
			})
			}
			</ul>
        </div>
    )}
}
class TodoList extends React.Component{
	constructor(){
		super();
		this.state = {
			isEditing : false
		}
	}
toggleTask = ()=>{
	let isEditing = this.state.isEditing;
	this.setState({
		isEditing:!isEditing
	})
}
UpdateItem = (evt)=>{
	evt.preventDefault();
	this.props.editTasks(this.props.index, this.input.value);
	this.toggleTask();
}
RenderForm = () =>{
	return(<form onSubmit={this.UpdateItem}>
			<input type="text" 
				defaultValue={this.props.detail.name}
				ref={(value)=>{this.input=value}}
			/>
			<button type="submit">Update Item</button>
		  </form>)
}
normalList = ()=>{
	return(
			<li onClick={()=>{
				this.props.clickHendler(this.props.index)
			}} className={this.props.detail.completed ? 'completed' : ''}>
			{this.props.detail.name}
			<button onClick={(evt)=>{
				evt.stopPropagation();
				this.props.deleteItem(this.props.index)
			}}>Delete Item</button>
			<button onClick={(evt)=>{
				evt.stopPropagation();
				this.toggleTask();
			}}>Edit Item</button>
			</li>
	)
}
	render(){
		const isEditing = this.state.isEditing;
		return(
			<section>
				{isEditing ? this.RenderForm() : this.normalList()}
			</section>
			
			
		)
	}
}
class TodoForm extends React.Component{
	render(){
		return(
			<section>
				<h1>To Do Form</h1>
				<form onSubmit={this.props.addText}>
				<input type="text" 
				value={this.props.currentText} 
				onChange={this.props.newText}
				/>
				<button type="submit">Submit</button>
			</form>
			</section>
		)
	}
}

export default About;