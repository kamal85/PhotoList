import React from 'react';
//import axios from 'axios';
//import Home from './home.js';

class PhotoDetail extends React.Component{

	render(){
		//const {photoDetail} = this.state;
		return(
				<div className="container">
				kamal
				</div>						
		)
	}
}
export default PhotoDetail;